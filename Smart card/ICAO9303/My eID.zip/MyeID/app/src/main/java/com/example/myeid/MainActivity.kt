package com.example.myeid

import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}

class MyHostApduService : HostApduService() {
    private  val msgOK = byteArrayOf(0x90.toByte(), 0x00.toByte())
    //(0x48.toByte(), 0x65.toByte(), 0x6c.toByte(), 0x6c.toByte(), 0x6f.toByte(), 0xC3.toByte())
    /*override fun processCommandApdu(commandApdu: ByteArray, extras: Bundle?): ByteArray {
        sendResponseApdu(msgOK)
        return null!!
    }*/

    override fun processCommandApdu(apdu: ByteArray, extras: Bundle?): ByteArray? {
        if (selectAidApdu(apdu)) {
            Log.i("HCEDEMO", "Application selected")
            sendResponseApdu(msgOK)
            //getWelcomeMessage()
        } else {
            Log.i("HCEDEMO", "Received: " + String(apdu))
            sendResponseApdu(apdu)
            //getNextMessage()
        }
        return null!!
    }

    private fun selectAidApdu(apdu: ByteArray): Boolean {
        return apdu.size >= 2 && apdu[0] == 0.toByte() && apdu[1] == 0xa4.toByte()
    }

    override fun onDeactivated(reason: Int) {
        Log.i("HCEDEMO", "Deactivated: $reason")
    }
}
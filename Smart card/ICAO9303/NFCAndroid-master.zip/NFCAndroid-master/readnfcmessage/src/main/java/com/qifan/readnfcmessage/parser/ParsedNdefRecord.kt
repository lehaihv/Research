package com.qifan.readnfcmessage.parser

/**
 * Created by Qifan on 05/12/2018.
 */

interface ParsedNdefRecord {
    fun str(): String
}